<div id="tratamento" class="tab-content">

</div>