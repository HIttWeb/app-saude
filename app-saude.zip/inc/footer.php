		<footer>
			<div class="box wrap-footer">
				<div class="left-side">
					<img src="./images/logo-30-anos.png" alt="">
				</div>
				<div class="right-side">
					<img src="./images/logo-ministerio-saude.png" alt="">					
				</div>
			</div>
		</footer>
	</div> <!-- END #container -->

	<script src="./js/jquery-1.11.1.min.js" type="text/javascript"></script>
	<script src="./js/jquery.timelinr-0.9.54.js" type="text/javascript"></script>	
	<script src="./js/scripts.js" type="text/javascript"></script>

</body>
</html>