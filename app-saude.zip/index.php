<?php include('./inc/header.php'); ?>

<section class="video-campanha">
	<a class="link-filme" href="javascript:void(0);">
		<img src="./images/bg-video-campanha.jpg" alt="">
	</a>
	<span class="tag">filme da campanha</span>

	<div class="wrap-video">
		<div class="content-video">
			<a href="javascript:void(0);" class="close-btn" title="Fechar Janela"></a>
			<video width="600" controls>
				<source src="./video/big_buck_bunny_720p_surround.avi" type="video/mp4">
				<source src="./video/big_buck_bunny_480p_stereo.ogg" type="video/ogg">
				Your browser does not support HTML5 video.
			</video>
		</div>
	</div>
	
</section>

<section class="linha-do-tempo">
	<h2>30 anos de luta e fatos históricos</h2>
	<div id="timeline">
		<ul id="issues">
			<li id="1980">
				<img src="./images/img-01-timeline.jpg" width="216"  />
			</li>
			<li id="1990">
				<img src="./images/img-02-timeline.jpg" width="216"  />
			</li>
			<li id="2000">
				<img src="./images/img-03-timeline.jpg" width="216"  />
			</li>
			<li id="atualmente">
				<img src="./images/img-03-timeline.jpg" width="216"  />
			</li>
		</ul>
		<ul id="dates">
			<li><a href="#1980">1980</a></li>
			<li><a href="#1990">1990</a></li>
			<li><a href="#2000">2000</a></li>
			<li><a href="#atualmente">Atualmente</a></li>
		</ul>
		<a href="#" id="next">+</a>
		<a href="#" id="prev">-</a>
	</div>
</section>

<section class="mosaico">
	<div class="wrap-abas">
		<ul class="tabs">
			<li>
				<a id="prevencao" class="tab" href="javascript:void(0);">prevenção</a>
			</li>
			<li>
				<a id="teste" class="tab" href="javascript:void(0);">teste</a>
			</li>
			<li>
				<a id="tratamento" class="tab" href="javascript:void(0);">tratamento</a>
			</li>
			<li>
				<a id="todos" class="tab ativo" href="javascript:void(0);">todos</a>
			</li>
		</ul>
		<div class="tabs-content-container">
			<?php include('./inc/prevencao.php'); ?>
			<?php include('./inc/teste.php'); ?>
			<?php include('./inc/tratamento.php'); ?>
			<?php include('./inc/todos.php'); ?>
		</div>
	</div>
</section>

<?php include('./inc/footer.php'); ?>